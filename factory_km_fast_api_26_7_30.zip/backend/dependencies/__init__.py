"""Shared dependency modules."""
