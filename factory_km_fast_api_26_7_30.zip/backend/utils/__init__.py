"""Shared utility modules."""
